MA SE MUESLI ONLINE SHOP - AFRIHOST DEPLOYMENT

Domain:
www.masemuesli.co.za

Included:
- Online product shop
- Cart
- Checkout form
- Product price: R80.00 per 1kg pack
- Affiliate & reseller programme
- Affiliate/reseller pricing: confirmed during onboarding
- iKhokha payment option
- PUDO delivery option
- PAXI delivery option
- The Courier Guy delivery option
- WhatsApp: 061 125 5233

IMPORTANT - LIVE PAYMENT AND DELIVERY CONNECTIONS
The website contains the customer-facing checkout flow, but it does NOT contain private merchant credentials.

To make iKhokha payments live, you will need your iKhokha merchant integration details/API or hosted checkout details.
To calculate live courier fees and create shipments automatically, you will need the relevant account/integration details for:
- PUDO
- PAXI
- The Courier Guy

Until those are connected, the checkout sends the completed order to WhatsApp for manual confirmation.

AFRIHOST UPLOAD
1. Log in to Afrihost ClientZone.
2. Open the hosting package for masemuesli.co.za.
3. Open File Manager.
4. Open the website root folder, usually public_html.
5. Upload the CONTENTS of this package into public_html.
6. Ensure index.html is directly inside public_html.
7. Confirm SSL/HTTPS is active.
8. Test the shop, cart, checkout and WhatsApp order button.


CONTACT DETAILS
General / Orders: info@masemuesli.co.za
Accounts: accounts@masemuesli.co.za
WhatsApp: 061 125 5233

FLAVOURS
Plain
Original
Berries
Tropical
Nuts

The website now includes a customer-friendly description for every flavour.
